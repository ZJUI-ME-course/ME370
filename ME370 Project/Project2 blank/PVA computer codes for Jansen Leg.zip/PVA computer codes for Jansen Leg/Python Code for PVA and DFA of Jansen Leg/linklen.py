import numpy as np

#this mimics the behavior of set_diff in MATLAB
def set_diff(input_set,elements):
    output = input_set.copy()
    if isinstance(elements, list):
        for element in elements:
            if element in output:
                output.remove(element)
    else:
        output.remove(elements)
    if len(output) == 1:
        output = output[0]
    return output

def set_intersection(set_1,set_2):
    output = list(set(set_1).intersection(set_2))
    if len(output) == 1:
        output = output[0]
    return output

def link_length_difference(dx,
                           dt,
                           node_positions,
                           non_ground_links_idx,
                           connectivity_matrix,
                           link_lengths,
                           non_fixed_nodes,
                           sliders,
                           links_with_fixed_angle,
                           link_fixed_angles,
                           crank_angular_velocity,
                           initial_node_positions,
                           motor_node_idx,
                           crank_tip_node_idx,
                           rotation_fixed_nodes,
                           rotation_fixed_nodes_vectors):
    #outputs the square difference between current link lengths and constrained link lengths
    #dx=[x1 x2 x3.... y1 y2 y3.....] %How to format dx| by breaking complex into x and y components

    length_difference = [] #initialize length difference
    node_positions_temp = node_positions.copy() #Copy to temp
    length_dx = len(non_fixed_nodes)*2

    #Allocation of objective function contributions from slider constraints
    slider_DOF = 0
    for slider in sliders:
     if slider[1]==4:
        slider_DOF = slider_DOF+1 # Middle node positon contribution to objective function 
     elif slider[1]==3:
        slider_DOF = slider_DOF+2 # Middle node position and length of links that make slider

    slider_difference = []

    for i,non_fixed_node in enumerate(non_fixed_nodes): #loop through non-fixed nodes
        node_positions_temp[non_fixed_node] = node_positions_temp[non_fixed_node] + dx[i]  #Adds the perturbation dx to the copy
        node_positions_temp[non_fixed_node] = node_positions_temp[non_fixed_node] + dx[int(length_dx/2)+i]*1j #Adds the perturbation dx to the copy


    for link_idx in non_ground_links_idx: #loop over links that are being readjusted
        delta = node_positions_temp[connectivity_matrix[link_idx][0]]-node_positions_temp[connectivity_matrix[link_idx][1]]
        length_difference.append(np.linalg.norm(delta)-link_lengths[link_idx]) #computes the length difference

    #Modifies dx for the slider joints according to sliding direction
    if len(sliders)>0:
        for slider in sliders:
            #If moving slider
            if len(slider)==3:
                node_1_idx = set_diff(connectivity_matrix[slider[1]],slider[0])
                node_2_idx = set_diff(connectivity_matrix[slider[2]],slider[0])
                
                #Calculates the distance from the line (2 slider endpoints) that the middle node is
                y2my1 = np.imag(node_positions_temp[node_2_idx]-node_positions_temp[node_1_idx])
                x2mx1 = np.real(node_positions_temp[node_2_idx]-node_positions_temp[node_1_idx])
                x2y1 = np.real(node_positions_temp[node_2_idx])*np.imag(node_positions_temp[node_1_idx])
                y2x1 = np.imag(node_positions_temp[node_2_idx])*np.real(node_positions_temp[node_1_idx])
                numerator = abs(y2my1*np.real(node_positions_temp[slider[0]])-x2mx1*np.imag(node_positions_temp[slider[0]])+x2y1-y2x1)
                denominator = np.sqrt(y2my1**2+x2mx1**2)
                slider_difference.append((numerator/denominator)) #Adds objective function contribution for distance middle slider node is from slider line
                
                # Adds objective function contribution to limit the length of the two slider links to the original combined length
                slider_difference.append(np.linalg.norm(node_positions_temp[node_2_idx]-node_positions_temp[node_1_idx])-(link_lengths[slider[1]]+link_lengths[slider[2]]))
            
            #If fixed slider
            if len(slider)==4:
                y2my1=slider[3]
                x2mx1=slider[2]
                x2y1=(slider[2]+np.real(initial_node_positions[slider[0]]))*np.imag(initial_node_positions[slider[0]])
                y2x1=(slider[3]+np.imag(initial_node_positions[slider[0]]))*np.real(initial_node_positions[slider[0]])
                numerator=abs(y2my1*np.real(node_positions_temp[slider[0]])-x2mx1*np.imag(node_positions_temp[slider[0]])+x2y1-y2x1)
                denominator=np.sqrt(y2my1**2+x2mx1**2)
                slider_difference.append((numerator/denominator)) #Adds objective function contribution for distance middle slider node is from slider line
        

    #Creates objective function contributions for fixed angle constraints
    #Calculates the difference in angle at fixed angle locations between adjustments
    angle_difference = []
    if len(link_fixed_angles)>0:
        for fixed_angle_idx,link_with_fixed_angle in enumerate(links_with_fixed_angle):
            common_node_idx = set_intersection(connectivity_matrix[link_with_fixed_angle[1]],connectivity_matrix[link_with_fixed_angle[0]])
            link_1_node_idx = set_diff(connectivity_matrix[link_with_fixed_angle[0]],common_node_idx)
            link_1_vec =  node_positions_temp[link_1_node_idx] - node_positions_temp[common_node_idx]
        
            link_2_node_idx = set_diff(connectivity_matrix[link_with_fixed_angle[1]],common_node_idx)
            link_2_vec = node_positions_temp[link_2_node_idx] - node_positions_temp[common_node_idx]
            new_angle = (np.real(link_1_vec)*np.real(link_2_vec)+np.imag(link_1_vec)*np.imag(link_2_vec))/(np.linalg.norm(link_1_vec)*np.linalg.norm(link_2_vec))  
            angle_difference.append(link_fixed_angles[fixed_angle_idx]-new_angle)

    #Creates objective function contributions for rotation fixed constraints
    #Calculates the difference in angle at for each vector at a fixed rotation location between adjustments 
    rotation_fixed_nodes_difference = []
    if len(rotation_fixed_nodes)>0:
        for rotation_fixed_node_idx,rotation_fixed_node in enumerate(rotation_fixed_nodes):       
            links_with_rotation_fixed_nodes,node_idx=np.where(np.array(connectivity_matrix)==rotation_fixed_node)
            for link_idx,link in enumerate(links_with_rotation_fixed_nodes):
                    non_rotation_fixed_node=connectivity_matrix[link][1-node_idx[link_idx]]
                    new_rotation_fixed_node_vector = node_positions_temp[non_rotation_fixed_node]-node_positions_temp[rotation_fixed_node]
                    old_rotation_fixed_node_vector = rotation_fixed_nodes_vectors[rotation_fixed_node_idx][link_idx]
                    rotation_fixed_angle_difference = 1-(np.real(new_rotation_fixed_node_vector)*np.real(old_rotation_fixed_node_vector)+np.imag(new_rotation_fixed_node_vector)*np.imag(old_rotation_fixed_node_vector))/(np.linalg.norm(new_rotation_fixed_node_vector)*np.linalg.norm(old_rotation_fixed_node_vector))              
                    rotation_fixed_nodes_difference.append(rotation_fixed_angle_difference)

    #Create total difference array
    total_difference_array = length_difference + slider_difference + angle_difference + rotation_fixed_nodes_difference

    #Add objective function contribution for angular velocity of crank.
    #Calculates the angular velocity difference between adjustments to match prescribed angular velocity
    new_crank_vector = node_positions_temp[crank_tip_node_idx]-node_positions_temp[motor_node_idx]
    old_crank_vector = node_positions[crank_tip_node_idx]-node_positions[motor_node_idx]
    perpdot = np.real(old_crank_vector)*np.imag(new_crank_vector) - np.imag(old_crank_vector)*np.real(new_crank_vector)
    change_in_angle = np.arcsin(perpdot/(np.linalg.norm(old_crank_vector)*np.linalg.norm(new_crank_vector)))*180/np.pi
    angular_velocity_difference = ((change_in_angle/dt)-crank_angular_velocity)
    total_difference_array.append(angular_velocity_difference)
    return np.array(total_difference_array)


