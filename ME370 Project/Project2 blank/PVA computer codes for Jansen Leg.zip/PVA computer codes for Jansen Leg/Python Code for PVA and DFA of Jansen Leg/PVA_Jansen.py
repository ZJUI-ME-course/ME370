#|Numerical PVA Code|University of Illinois at Urbana-Champaign| 
#|ME 370|Created by Brian C. McGuigan for MATLAB adapted by Ali Ibrahim A Albazroun for Python

#Section0:Imports
import numpy as np
from PVA_solved import PVA

#Section1:Input
initial_node_postions = np.array([0.038+0.0078j,0.0455+0.0208j,0+0.0415j,0.0183-0.0348j,0+0j,-0.040+.0026j,-0.0181-0.0302j,0.0199-0.0838j]) # Node/Joint Placement
connectivity_matrix = [[0,1],[1,2],[1,3],[2,4],[2,5],[4,5],[3,4],[5,6],[3,6],[6,7],[3,7],[0,4]] #Connectivity Matrix
ground_links_idx = [11] #indices of grounded links (index of row in connectivity matrix)
crank_link_idx = 0 # Link with prescribed position over time (input crank)
motor_node_idx = 0 #Node the motor is at.
sliders = [] #Slider constraints #[node index,link 1 index, link 2 index] or [node index,link index, x direction, y direction]
links_with_fixed_angle = [] #Fix link/link angle during rotation. (Must share a node)
rotation_fixed_nodes = [] #Nodes that are fixed so that they cant rotate
slider_friction = [] #Friction at slider constraints

tperiod=5 #total time to run simulation (seconds)
dt=0.01 #time step (seconds)
crank_angular_velocity=150 #Angular velocity of input crank (deg/sec) -Assumed constant.
             #+(-) angular velocity denotes CCW (CW) rotation

plotting_node_idx = 7 # for plotting the position, velocity, acceleration over time

if __name__ == "__main__":
    #call the PVA
    n_timesteps,node_positions,velocity,acceleration = PVA(
    initial_node_postions,
    connectivity_matrix,
    ground_links_idx,
    crank_link_idx,
    motor_node_idx,
    sliders,
    links_with_fixed_angle,
    rotation_fixed_nodes,
    tperiod,
    dt,
    crank_angular_velocity,
    plotting_node_idx,
    )