#|Numerical PVA Code|University of Illinois at Urbana-Champaign| 
#|ME 370|Created by Brian C. McGuigan for MATLAB adapted by Ali Ibrahim A Albazroun for Python

#Section0:Imports
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
from scipy.optimize import least_squares
from functools import partial
from linklen import (link_length_difference,set_diff,set_intersection)

def PVA(
    initial_node_positions,
    connectivity_matrix,
    ground_links_idx,
    crank_link_idx,
    motor_node_idx,
    sliders,
    links_with_fixed_angle,
    rotation_fixed_nodes,
    tperiod,
    dt,
    crank_angular_velocity,
    plotting_node_idx,
):

    n_timesteps=int(tperiod/dt) #Total number of timesteps
    time= np.linspace(0,tperiod,n_timesteps) #array holding the amount of time that has passed
    
    #Section 2: Useful information about the sytem
    ground_links = []
    for ground_link_idx in ground_links_idx:
        ground_links += connectivity_matrix[ground_link_idx]
    ground_link_nodes = list(set(ground_links)) #this removes duplicate nodes

    fixed_nodes = ground_link_nodes.copy()
    for slider in sliders:
        if slider[0] in fixed_nodes:
            fixed_nodes.remove(slider[0])

    non_fixed_nodes = list(range(len(initial_node_positions))) #Nodes without prescribed/fixed placement (the ones that can vary after we move crank link a bit)
    if len(fixed_nodes)>0:
        non_fixed_nodes = set_diff(non_fixed_nodes,fixed_nodes) #remove fixed nodes
    crank_tip_node_idx = set_diff(connectivity_matrix[crank_link_idx],motor_node_idx) #Node index denoting the tip of the input crank link

    n_DOF=len(non_fixed_nodes)*2
    non_ground_links_idx = set_diff(list(range(len(connectivity_matrix))),ground_link_idx) #links that may have varying lengths after a timestep

    #Slider information used for DFA
    slider_links=[]
    slider_end_nodes=[]
    for slider_idx,slider in enumerate(sliders):
        if slider[1] in non_ground_links_idx:
            non_ground_links_idx.remove(slider[1])
        if len(slider)==3:
            non_ground_links_idx.remove(slider[2])
            slider_links.append([slider_idx,slider[1], slider[2]]) #total list of all slider links [slider_index, link1_index, link2_index]
            common_node= set_intersection(connectivity_matrix[slider[1]],connectivity_matrix[slider[2]])
            end_nodes = set_diff(set(connectivity_matrix[slider[1]] + connectivity_matrix[slider[2]]),common_node)
            slider_end_nodes.append(end_nodes)


    #Section 3: Allocation/Initialization
    node_positions = np.zeros((initial_node_positions.shape[0],n_timesteps),dtype=np.complex128) #allocate node positions over all time steps 
    node_positions[:,0] = initial_node_positions #Initialize current timestep (put in initial node position data)

    #Section 4: Put in initial fixed ground link nodes positions at each time step in corresponding position array since they are fixed
    for i in range(1,n_timesteps):
        node_positions[ground_link_nodes,i] = initial_node_positions[ground_link_nodes]

    #Section 6: Computes link lengths from initial node positions
    link_lengths=np.zeros((len(connectivity_matrix),)) #Allocate array for link lengths
    
    for link_idx,link_nodes in enumerate(connectivity_matrix): #loop over connectivity matrix
        delta = initial_node_positions[link_nodes[1]]-initial_node_positions[link_nodes[0]]
        link_lengths[link_idx] = np.linalg.norm(delta) #compute length between nodes

    #Compute initial link angle for fixed angle constraint
    link_fixed_angles= []
    rotation_fixed_nodes_vectors = {}

    #Calculates the initial angles for the fixed angle constraints
    for fixed_angle_idx,link_with_fixed_angle in enumerate(links_with_fixed_angle):
        common_node_idx = set_intersection(connectivity_matrix[link_with_fixed_angle[1]],connectivity_matrix[link_with_fixed_angle[0]])
        link_1_node_idx = set_diff(connectivity_matrix[link_with_fixed_angle[0]],common_node_idx)
        link_1_vec = initial_node_positions[link_1_node_idx]-initial_node_positions[common_node_idx]
    
        link_2_node_idx = set_diff(connectivity_matrix[link_with_fixed_angle[1]],common_node_idx)
        link_2_vec = initial_node_positions[link_2_node_idx]-initial_node_positions[common_node_idx]
        link_fixed_angles.append((np.real(link_1_vec)*np.real(link_2_vec)+np.imag(link_1_vec)*np.imag(link_2_vec))/(np.linalg.norm(link_1_vec)*np.linalg.norm(link_2_vec)))

    #Calculates the initial link vectors from each rotation fixed constraint location
    if len(rotation_fixed_nodes)>0:
        for rotation_fixed_node_idx,rotation_fixed_node in enumerate(rotation_fixed_nodes):       
            links_with_rotation_fixed_nodes,node_idx=np.where(np.array(connectivity_matrix)==rotation_fixed_node)
            rotation_fixed_nodes_vectors[rotation_fixed_node_idx] = np.zeros((len(links_with_rotation_fixed_nodes),),dtype=np.complex128)
            for link_idx,link in enumerate(links_with_rotation_fixed_nodes):
                non_rotation_fixed_node=connectivity_matrix[link][1-node_idx[link_idx]]
                rotation_fixed_nodes_vectors[rotation_fixed_node_idx][link_idx] = initial_node_positions[non_rotation_fixed_node]-initial_node_positions[rotation_fixed_node]

    #Section 7: Loop over each time step and find adjustments that preserve link lengths
    print('Running Simulation:') #Make string
    new_link_lengths = np.zeros((len(non_ground_links_idx),1)) #Allocate array for new link lengths (link lengths that could change in objective function after dx is solved

    for i in range(n_timesteps-1):
        node_positions[non_fixed_nodes,i+1]=node_positions[non_fixed_nodes,i] #copy previous non_fixed_nodes quantities to current timestep
        func=partial(link_length_difference,
                    dt = dt,
                    node_positions = node_positions[:,i+1],
                    non_ground_links_idx = non_ground_links_idx,
                    connectivity_matrix = connectivity_matrix,
                    link_lengths = link_lengths[:],
                    non_fixed_nodes = non_fixed_nodes,
                    sliders = sliders,
                    links_with_fixed_angle = links_with_fixed_angle,
                    link_fixed_angles = link_fixed_angles,
                    crank_angular_velocity = crank_angular_velocity,
                    initial_node_positions = initial_node_positions,
                    motor_node_idx = motor_node_idx,
                    crank_tip_node_idx = crank_tip_node_idx,
                    rotation_fixed_nodes = rotation_fixed_nodes,
                    rotation_fixed_nodes_vectors = rotation_fixed_nodes_vectors) #make this a function of dx only
        optimization_result = least_squares(func,
                            1e-6*np.ones((n_DOF,)),
                            method="lm",
                            ftol = 1e-12,
                            xtol = 1e-12,
                            gtol = 1e-12,) #Solve for non_fixed_nodes perturbation distance that fixes link length incompatibilities
        dxnfx = optimization_result.x
        node_positions[non_fixed_nodes,i+1] += dxnfx[:int(n_DOF/2)] #add real part correction
        node_positions[non_fixed_nodes,i+1] += dxnfx[int(n_DOF/2):]*1j # add imaginary part correction
        
        #Loops over each link that can have varied length to compute new link lengths (They should be constant if solved correctly)
        for k,link_idx in enumerate(non_ground_links_idx): #loop over all links
            delta = node_positions[connectivity_matrix[link_idx][0],i+1]-node_positions[connectivity_matrix[link_idx][1],i+1]
            new_link_lengths[k] = np.linalg.norm(delta) #compute length between nodes

        linksnewtot = np.sum(new_link_lengths) #Sums new link lengths (this should equal np.sum(link_lengths[non_ground_links_idx]) during whole simulation)
        
        percdone=(i/n_timesteps)*100.0; # Percentage of simulation calculated
        print('Progress={0:.2f}%: i={1} :Total Link Lengths={2:.2f},'.format(percdone,i,linksnewtot)) #Make string with progress info


    #Section 8: Animate Linkage
    xmin=np.min(np.real(node_positions))
    xmax=np.max(np.real(node_positions))
    x_scale = xmax-xmin
    ymin=np.min(np.imag(node_positions))
    ymax=np.max(np.imag(node_positions))
    y_scale = ymax-ymin


    fig = plt.figure()  
    ax_linkage = plt.axes(xlim =(xmin-0.2*x_scale, xmax+0.2*x_scale), 
                    ylim =(ymin-0.2*y_scale, ymax+0.2*y_scale))  


    fig.subplots_adjust(bottom=0.25) #space for slider
    fig.subplots_adjust(left=0) #space for legend

    # Make a vertically oriented slider to control the time
    axtime = fig.add_axes([0.25, 0.1, 0.65, 0.03])
    time_slider = Slider(
        ax=axtime,
        label="Time (seconds)",
        valmin=0,
        valmax=tperiod-dt,
        valinit=0,
        orientation="horizontal"
    )

    # animation function
    def animate_linkage(i): 
        ax_linkage.cla()
        ax_linkage.set_xlim((xmin-0.01*x_scale, xmax+0.01*x_scale)) 
        ax_linkage.set_ylim((ymin-0.01*y_scale, ymax+0.01*y_scale))
        ax_linkage.set_aspect('equal', adjustable='box')
        trace_points = node_positions[:,:i]

        #start with trace so it does not cover the linkage
        for node_idx,node_coord in enumerate(initial_node_positions):
            ax_linkage.plot(np.real(trace_points[node_idx,:]),np.imag(trace_points[node_idx,:]),'.k',markersize = 1) #trace node positions every timestep
            
        for link_idx,link in enumerate(connectivity_matrix): #loop over links
            #If groundlink, plot dashed line, else make solid
            if link_idx in ground_links_idx:
                ax_linkage.plot(np.real(node_positions[link,i]),np.imag(node_positions[link,i]),"--",label="Link {0}".format(link_idx+1),linewidth=2) #Plot dashed line between
            else:
                ax_linkage.plot(np.real(node_positions[link,i]),np.imag(node_positions[link,i]),label="Link {0}".format(link_idx+1),linewidth=2) #Plot line between   
        
        prop_cycle = plt.rcParams['axes.prop_cycle']
        colors = prop_cycle.by_key()['color']
        for node_idx,node_coord in enumerate(initial_node_positions):
            ax_linkage.plot(np.real(node_positions[node_idx,i]),np.imag(node_positions[node_idx,i]),'o',label="Node {0}".format(node_idx+1),color = colors[node_idx]) #Plot position of each node as black dot 

        ax_linkage.legend(loc='center left', bbox_to_anchor=(1, 0.5))

    animate_linkage(0)
    # The function to be called anytime a slider's value changes
    def update(val):
        animate_linkage(int(time_slider.val/dt))
        fig.canvas.draw_idle()

    # register the update function with each slider
    time_slider.on_changed(update)

    # calling the animation function      
    # anim = animation.FuncAnimation(fig, animate_linkage, frames = n_timesteps, interval = dt*1000, repeat=False)

    plt.show()
    plt.close()


    #Section 9: Compute Velocity and Acceleration of nodes

    #Velocity Calculation
    velocity = np.zeros_like(node_positions)
    for i in range(n_timesteps):
        if i==0:
            velocity[:,i] = (node_positions[:,i+1]-node_positions[:,i])/dt
        elif i==n_timesteps-1:
            velocity[:,i] = (node_positions[:,i]-node_positions[:,i-1])/dt
        else:
            velocity[:,i] = (node_positions[:,i+1]-node_positions[:,i-1])/(2*dt)


    #Acceleration code goes here
    acceleration = np.zeros_like(node_positions)
    for i in range(n_timesteps):
        if i==0:
            acceleration[:,i] = (velocity[:,i+1]-velocity[:,i])/dt
        elif i==n_timesteps-1:
            acceleration[:,i] = (velocity[:,i]-velocity[:,i-1])/dt
        else:
            acceleration[:,i] = (velocity[:,i+1]-velocity[:,i-1])/(2*dt)


    #Additional smoothening of the position/velocity data may need to be implemented if there are "spikes" in the acceleration.
    #This has to do with the stability of the numerical procedure used?
    #plot node positions
    plt.plot(time, np.real(node_positions[plotting_node_idx,:]),label="X-Pos")
    plt.plot(time, np.imag(node_positions[plotting_node_idx,:]),label="Y-Pos")
    plt.xlabel("Time (Seconds)")
    plt.ylabel("Position (m)")
    plt.title('Node {0} Position over Time'.format(plotting_node_idx+1)) #+1 to convert python index to normal convection
    plt.legend()
    plt.show()
    plt.close()

    #plot node velocities
    plt.plot(time, np.real(velocity[plotting_node_idx,:]),label="X-Vel")
    plt.plot(time, np.imag(velocity[plotting_node_idx,:]),label="Y-Vel")
    plt.xlabel("Time (Seconds)")
    plt.ylabel("Velocity (m/s)")
    plt.title('Node {0} Velocity over Time'.format(plotting_node_idx+1)) #+1 to convert python index to normal convection
    plt.legend()
    plt.show()
    plt.close()

    #plot node accelerations
    plt.plot(time, np.real(acceleration[plotting_node_idx,:]),label="X-Accel")
    plt.plot(time, np.imag(acceleration[plotting_node_idx,:]),label="Y-Accel")
    plt.xlabel("Time (Seconds)")
    plt.ylabel("Acceleration (m/s)")
    plt.title('Node {0} Acceleration over Time'.format(plotting_node_idx+1)) #+1 to convert python index to normal convection
    plt.legend()
    plt.show()
    plt.close()

    # Add Code to find the crank angle
    crank_delta_x = np.real(node_positions[crank_tip_node_idx,0]-node_positions[motor_node_idx,0])
    crank_delta_y = np.imag(node_positions[crank_tip_node_idx,0]-node_positions[motor_node_idx,0])
    crank_initial_angle = np.arctan2(crank_delta_y,crank_delta_x)*180/np.pi
    crank_angle = (crank_initial_angle+time*crank_angular_velocity)

    # Add Plots as a function of crank angle
    #plot node positions
    plt.plot(crank_angle, np.real(node_positions[plotting_node_idx,:]),label="X-Pos")
    plt.plot(crank_angle, np.imag(node_positions[plotting_node_idx,:]),label="Y-Pos")
    plt.xlabel("Crank Angle (Degrees)")
    plt.ylabel("Position (m)")
    plt.title('Node {0} Position with Crank Angle'.format(plotting_node_idx+1)) #+1 to convert python index to normal convection
    plt.legend()
    plt.show()
    plt.close()

    #plot node velocities
    plt.plot(crank_angle, np.real(velocity[plotting_node_idx,:]),label="X-Vel")
    plt.plot(crank_angle, np.imag(velocity[plotting_node_idx,:]),label="Y-Vel")
    plt.xlabel("Crank Angle (Degrees)")
    plt.ylabel("Velocity (m/s)")
    plt.title('Node {0} Velocity with Crank Angle'.format(plotting_node_idx+1)) #+1 to convert python index to normal convection
    plt.legend()
    plt.show()
    plt.close()

    #plot node accelerations
    plt.plot(crank_angle, np.real(acceleration[plotting_node_idx,:]),label="X-Accel")
    plt.plot(crank_angle, np.imag(acceleration[plotting_node_idx,:]),label="Y-Accel")
    plt.xlabel("Crank Angle (Degrees)")
    plt.ylabel("Acceleration (m/s)")
    plt.title('Node {0} Acceleration with Crank Angle'.format(plotting_node_idx+1)) #+1 to convert python index to normal convection
    plt.legend()
    plt.show()
    plt.close()


    return n_timesteps,node_positions,velocity,acceleration