%|Numerical DFA Code|University of Illinois at Urbana-Champaign| 
%|ME 370|Created by Shuvankar Goswami
tic
clear
clc

%% Section0: call PVA.m
PVA_P3_solution;

%% Section1:Input
cmlink = [0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5; 0.5]; %Fractional link distance from 1st node where the center of mass lies
%Defined in the order cmat is defined in the PVA
cmatbody = {1; 2; 3; [4 5 6]; 7; 8; [9 10 11]; 12}; %Defining rigid bodies as a cell array
%Note that in PVA, each link was defined to be binary. Links modeled with a fixed angle constraint are physically rigid.

gconst=9.81; %gravitational constant in m/s^2 (positive)
wdth=0.018; %Width of each link (meters).  
tks=0.006; %thickness of each link (meters). 
den=1190; %Density for each link (kg/m^3). 
gndbodyidx = 8; %Index number of the ground body in cmatbody cell array(row of cmatbody denoting ground).
Bodymass = 0.8; %mass of the robot body.(kg)
Fnormal = Bodymass*gconst; %Weight of the robot body.(N)

%% Section2: Calculates the mass of each link using the previously defined link lengths
% and the above constant width, thickness, and density
Mlink=zeros(length(cmat),1); %Mass of each binary link
for i=1:length(cmat)
    Mlink(i)=links(i,1)*den*wdth*tks;
end
M=zeros(length(cmatbody),1); %Mass of each rigid body
for i=1:length(cmatbody)
    if length(cmatbody{i}) == 1 %Body consists of one link
        M(i)=Mlink(cmatbody{i}); %calculates mass of body i
    else
        M(i)=sum(Mlink(cmatbody{i}(:))); 
    end
end

%% Section 3: Calculate center of mass and moment of inertia for each link
%and rigid body
r1link = zeros(length(cmat),tnum); 
r2link = zeros(length(cmat),tnum);
rcglink = zeros(length(cmat),tnum); %Position of center of mass for link as complex number.
for k=1:tnum %loops over all timesteps of simulation
    for i=1:length(cmat) %loops over all links
        
        nd1ind=cmat(i,1); %node 1 index of link i
        nd2ind=cmat(i,2); %node 2 index of link i
        r2link(i,k)=xnode(nd2ind,k); %Position of node 2 for link i
        r1link(i,k)=xnode(nd1ind,k); %Position of node 1 for link i
        rcglink(i,k)=cmlink(i)*(r2link(i,k)-r1link(i,k))+r1link(i,k); 
    end
end

rcg = zeros(length(cmatbody),tnum); %Position of center of mass for each body
for k=1:tnum
    for i=1:length(cmatbody)
        if length(cmatbody{i}) == 1
            rcg(i,k)=rcglink(cmatbody{i},k);
        else
            rcg(i,k)=(sum(Mlink(cmatbody{i}(:)).*rcglink(cmatbody{i}(:),k)))...
                /(sum(Mlink(cmatbody{i}(:)))); %Position of center of mass of each body
        end
    end
end
        
Ilink = zeros(length(cmat),1); %Moment of Inertia of each binary link
for i=1:length(cmat)
    Ilink(i)=Mlink(i)*(wdth^2+links(i,1).^2)/12;
end

I = zeros(length(cmatbody),1); %Moment of inertias for each link. Single column matrix where row i is the moment of inertia of link i
for i=1:length(cmatbody)
    if length(cmatbody{i}) == 1
        I(i)=Ilink(cmatbody{i}); %moment of inertia of rectangular link through center
    else
        I(i)=sum(Mlink(cmatbody{i}(:)).*(abs(rcg(i,1)-rcglink((cmatbody{i}(:)),1))).^2+...
            Ilink(cmatbody{i}(:))); %Parallel Axis Theorem: I = Ic +md^2
    end
end

%% Section4: Calculates theta, omega and alpha of each body

thetalink=zeros(length(cmat),tnum); %allocate angles over all time steps
for k=1:tnum
    thetalink(1:end,k) = angle(xnode(cmat(1:end,2),k)...
        -xnode(cmat(1:end,1),k)); %Calculation of theta for each link IN RADIANS
end

theta = zeros(length(cmatbody),tnum);
for i=1:length(cmatbody)
    if length(cmatbody{i}) == 1
        theta(i,1:end)=thetalink(cmatbody{i},1:end); %Calculation of theta for each body IN RADIANS
    else
        theta(i,1:end)=thetalink(cmatbody{i}(1),1:end); %Choose an arbitrary link - does not matter
    end
end

omega=zeros(length(cmatbody),tnum-1); %omega for each body in radians/sec
for k=1:tnum-1
    if k==1
        omega(:,k)=(theta(:,k+1)-theta(:,k))/dt;
    else
        omega(:,k)=(theta(:,k+1)-theta(:,k-1))/(2*dt);
    end
end %Calculation similar to velocity calculation in PVA

for i = 1:length(cmatbody)
    if cmatbody{i}==crlink
        omega(i,:) = deg2rad(crangvel); %We know omega of the crank
    end
end

alpha=zeros(length(cmatbody),tnum-2); %omega for each body in radians/sec
for k=1:tnum-2
    if k==1
        alpha(:,k)=(omega(:,k+1)-omega(:,k))/dt;
    else
        alpha(:,k)=(omega(:,k+1)-omega(:,k-1))/(2*dt);
    end
end %Calculation similar to acceleration calculation in PVA

%% Section5: Calculates the linear acceleration of each link's center of
%mass/gravity by differentiating rcg and then vcg

vcg=zeros(length(cmatbody),tnum-1); %linear velocity for each center of gravity
acg=zeros(length(cmatbody),tnum-2); %linear acceleration for each center of gravity

for k=1:tnum-1
    if k==1
        vcg(:,k)=(rcg(:,k+1)-rcg(:,k))/dt;
    else
        vcg(:,k)=(rcg(:,k+1)-rcg(:,k-1))/(2*dt);
    end
end %Calculation similar to velocity calculation in PVA

for k=1:tnum-2
    if k==1
        acg(:,k)=(vcg(:,k+1)-vcg(:,k))/dt;
    else
        acg(:,k)=(vcg(:,k+1)-vcg(:,k-1))/(2*dt);
    end
end %Calculation similar to acceleration calculation in PVA

%% Section6: Allocates B, external forces and moving bodies
neqs=3*(length(cmatbody)-length(gndlink)); %Number of equations. Sum of Fx,Fy,Torque for all links except ground.
B=zeros(neqs,tnum-2);%Allocate solution vector

%%-----Define External Forces here (does not include link weights)-----%%
% Do not 
%  F = []; %F1 as a complex number
%  body_F = []; %Link Index where F1 Acts
%  node_F = []; %Node where F1 acts
% If an external force acts on the cg of a body, leave that value of node_F1 as zero.

bodynotgnd = (1:length(cmatbody))';
for i=1:length(gndlink)
    bodynotgnd=bodynotgnd(bodynotgnd~=gndbodyidx);
end

%% Section7: Fills in link components (Sum Fx,Fy,M) in A,C matrix/vector

for k=1:tnum-2
    A = zeros(neqs,neqs);
    C = zeros(neqs,1);
    RG1 = xnode(1,k)-rcg(1,k);
    R231 = xnode(2,k)-rcg(1,k);
    R132 = xnode(2,k)-rcg(2,k);
    RA2 = xnode(3,k)-rcg(2,k);
    R123 = xnode(2,k)-rcg(3,k);
    RB73 = xnode(4,k)-rcg(3,k);
    R2A = xnode(3,k)-rcg(4,k);
    R8A = xnode(6,k)-rcg(4,k);
    RG7A = xnode(5,k)-rcg(4,k);
    RAG7 = xnode(5,k)-rcg(5,k);
    RB37 = xnode(4,k)-rcg(5,k);
    RA8 = xnode(6,k)-rcg(6,k);
    RB8 = xnode(7,k)-rcg(6,k);
    R73B = xnode(4,k)-rcg(7,k);
    R8B = xnode(7,k)-rcg(7,k);
    RGB = xnode(8,k)-rcg(7,k);
    
    A(1:2,1:4) = [1 0 1 0; 0 1 0 1];
    A(3,1:4) = [-imag(RG1), real(RG1), -imag(R231), real(R231)];
    A(3,end) = 1;
    A(4:5,5:8) = [1 0 1 0; 0 1 0 1];
    A(6,5:8) = [-imag(R132), real(R132), -imag(RA2), real(RA2)];
    A(7:8,3:6) = [-1 0 -1 0; 0 -1 0 -1];
    A(7:8,9:10) = [1 0; 0 1];
    A(9,3:6) = [imag(R123), -real(R123), imag(R123), -real(R123)];
    A(9,9:10) = [-imag(RB73), real(RB73)];
    A(10:11,7:14) = [-1 0 0 0 1 0 1 0; 0 -1 0 0 0 1 0 1];
    A(12,7:8) = [imag(R2A), -real(R2A)];
    A(12,11:14) = [-imag(R8A), real(R8A), -imag(RG7A), real(RG7A)];
    A(13:14,15:18) = [1 0 1 0; 0 1 0 1];
    A(15,15:18) = [-imag(RAG7), real(RAG7), -imag(RB37), real(RB37)];
    A(16:17,11:12) = [-1 0; 0 -1];
    A(16:17,19:20) = [-1 0; 0 -1];
    A(18,11:12) = [imag(RA8), -real(RA8)];
    A(18,19:20) = [imag(RB8), -real(RB8)];
    A(19:20,9:10) = [-1 0; 0 -1];
    A(19:20,17:20) = [-1 0 1 0 ; 0 -1 0 1];
    A(21,9:10) = [imag(R73B), -real(R73B)];
    A(21,17:20) = [imag(R73B), -real(R73B), -imag(R8B), real(R8B)]; 
        
    for i=1:length(bodynotgnd)
        C(3*i-2)=M(bodynotgnd(i))*real(acg(bodynotgnd(i),k));
        C(3*i-1)=M(bodynotgnd(i))*imag(acg(bodynotgnd(i),k));%+M(bodynotgnd(i))*gconst;
        C(3*i)=I(bodynotgnd(i))*alpha(bodynotgnd(i),k);
%         if ~isempty(F)
%             for j=1:length(F)
%                 if bodynotgnd(i) == body_F(j)
%                     C(3*i-2)=C(3*i-2)-real(F(j));
%                     C(3*i-1)=C(3*i-1)-imag(F(j));
%                     if node_F(j) ~= 0
%                         C(3*i)=C(3*i)-(real(xnode(node_F(j),k)-rcg(body_F(j),k)))*imag(F(j))+...
%                             (imag(xnode(node_F(j),k)-rcg(body_F(j),k)))*real(F(j));
%                     end
%                 end
%             end
%         end
    end
    
    C(20)=C(20)- Fnormal;
    C(21)=C(21)- Fnormal*real(RGB);
    
    B(:,k) = A\C;
end
%% Section 8: Comparison with Principle of Virtual Work

% height_cg=imag(rcg);
% 
% E=zeros(length(cmatbody),tnum-1);
% 
% for i=bodynotgnd
%     for k=1:tnum-1
%         E(i,k)=E(i,k)+0.5.*M(i).*(abs(vcg(i,k)).^2)+0.5.*I(i).*(omega(i,k).^2)+M(i).*gconst.*height_cg(i,k);
%     end
% end
% 
% E = sum(E);
% 
% dEdt=zeros(1,tnum-2);
% 
% for k=1:tnum-2
%     if k==1
%         dEdt(k)=(E(k+1)-E(k))/dt;
%     else
%         dEdt(k)=(E(k+1)-E(k-1))/(2*dt);
%     end
% end

% torque = B(21,:);
% 

% VWexternal = zeros(1,tnum-2);
% for k = 1:tnum-2
%     VWexternal(k) = torque(k)*omega(2,k);
%     if ~isempty(F)
%         for j=1:length(F)
%             if node_F(j) == 0
%                 VWexternal(k) = VWexternal(k)+real(dot(F(j),vcg(body_F(j),k)));
%             else               
%                 VWexternal(k) = VWexternal(k)+real(dot(F(j),velocity(node_F(j),k)));
%             end
%         end
%     end
% end
%% Section 9: Plots

torque = B(21,:);

FAG7x = B(15,:);
FAG7y = B(16,:);
FG7Ax = B(13,:);
FG7Ay = B(14,:);

FA7Gx = -FAG7x-FG7Ax;
FA7Gy = -FAG7y-FG7Ay;

FG1x = B(1,:);
FG1y = B(2,:);

F1Gx = -FG1x;
F1Gy = -FG1y;

figure
plot(time(1:tnum-2),torque(1:tnum-2))
formatplot(gcf,gca,title('Motor Torque'),xlabel('t (sec)'),ylabel('Torque (Nm)'))

figure
plot(time(1:tnum-2),FA7Gx(1:tnum-2),'r')
hold on
plot(time(1:tnum-2),F1Gx(1:tnum-2),'b')
formatplot(gcf,gca,title('Forces exerted on Ground at O2 and O4 (x-component)'),xlabel('t (sec)'),ylabel('Force (N)'))
legend('Force at O4','Force at O2','Location','southoutside')

figure
plot(time(1:tnum-2),FA7Gy(1:tnum-2),'r')
hold on
plot(time(1:tnum-2),F1Gy(1:tnum-2),'b')
formatplot(gcf,gca,title('Forces exerted on Ground at O2 and O4 (y-component)'),xlabel('t (sec)'),ylabel('Force (N)'))
legend('Force at O4','Force at O2','Location','southoutside')


% figure
% plot(time(1:tnum-2),VWexternal,'r','LineWidth',2)
% hold on
% plot(time(1:tnum-2),dEdt,'k--','LineWidth',2)
% legend('Power from external forces and torques','Power from inertial properties','Location','southoutside')
% formatplot(gcf,gca,title('Power'),xlabel('t'),ylabel('Power'))
% toc